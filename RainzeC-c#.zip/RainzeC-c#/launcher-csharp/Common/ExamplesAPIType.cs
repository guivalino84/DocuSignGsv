﻿namespace DocuSign.CodeExamples.Common
{
    public enum ExamplesAPIType
    {
        Rooms,
        ESignature
    }
}
