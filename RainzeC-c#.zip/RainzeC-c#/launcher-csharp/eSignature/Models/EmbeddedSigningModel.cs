﻿namespace DocuSign.CodeExamples.Views
{
    public class EmbeddedSigningModel
    {
        public string SingerEmail { get; set; }
        public string SingerName { get; set; }
    }
}